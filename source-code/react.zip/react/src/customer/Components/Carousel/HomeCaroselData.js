export const homeCarouselData=[
    {
        image:"https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1705683011/Croma%20Assets/CMS/Homepage%20Banners/HP%20Rotating/2024/Jan/20%20Jan/Desktop/HP_oneplus_20Jan2024_k9onqv.jpg?tr=w-2048",
        path:"/women/clothing/lengha_choli"
    },
    {
        image:"https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1705731880/Croma%20Assets/CMS/LP%20Page%20Banners/2024/Sanity/HP/Jan/20012024/HP_laptop_20Jan2024_lql4a3.jpg?tr=w-2048",
        path:"/women/clothing/women_dress"
    },
    {
        image:"https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1705731881/Croma%20Assets/CMS/LP%20Page%20Banners/2024/Sanity/HP/Jan/20012024/HP_tab_20Jan2024_iywjzi.jpg?tr=w-2048",
        path:"/women/clothing/women_dress"
    },
    {
        image:"https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1702044593/Croma%20Assets/CMS/LP%20Page%20Banners/2023/Deals%20Corner/2023/Dec/Rotating/HP/HP_DealsCorner_GIF_Compressed_8Dec2023_gazl4l.gif?tr=w-2048",
        path:"/women/clothing/women_saree"
    },
    
      

]

