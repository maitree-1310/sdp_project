import { Box } from 'mdi-material-ui'
import React from 'react'

const CreateProuductDemo = () => {
  return (
    <Box className='text-black'>
        
    </Box>
  )
}

export default CreateProuductDemo